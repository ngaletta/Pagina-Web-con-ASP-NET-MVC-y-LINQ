﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TpFinalPNTCarrito.Helpers
{
    public class Alias
    {
        public const string PersonaDocumento = "Documento";
        public const string CorreoElectronico = "Correo electrónico";
    }
}